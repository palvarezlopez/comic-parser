def comic_Parser():
    print("Test comicParser")