def parser():
    print("Test comicParser")