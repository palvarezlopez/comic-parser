import comicParser

# create instance of comic parser
comicParser.ComicParser()