import sys
from . import comicParser

# run parser
def runParser():
    # create instance of comic parser    
    comicParser.ComicParser(sys.argv)