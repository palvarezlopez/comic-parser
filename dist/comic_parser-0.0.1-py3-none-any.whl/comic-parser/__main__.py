from . import comic_Parser

if __name__ == '__main__':
    comic_Parser()